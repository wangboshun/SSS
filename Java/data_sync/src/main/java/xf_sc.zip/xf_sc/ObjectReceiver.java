package xf_sc;

/**
 * @author WBS
 * Date:2022/6/11
 */

public interface ObjectReceiver {
    public Object getFromReader();
}
